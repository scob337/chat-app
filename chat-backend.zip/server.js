require('dotenv').config();
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const { initSocket } = require('./sockets/socket');
const authRoutes = require('./routes/auth');
const friendsRoutes = require('./routes/friends');
const groupsRoutes = require('./routes/groups');

const app = express();
const server = http.createServer(app);

app.use(express.json());
app.use(cookieParser());

// Routes
app.use('/auth', authRoutes);
app.use('/friends', friendsRoutes);
app.use('/groups', groupsRoutes);

const PORT = process.env.PORT || 8080;

// DB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/chatapp', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(()=> {
  console.log('MongoDB connected');
  server.listen(PORT, ()=> console.log('Server running on port', PORT));
}).catch(err => {
  console.error('DB connection error:', err);
});

// init socket.io
initSocket(server);
